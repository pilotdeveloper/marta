  
#ifndef __RF24_INCLUDES_H__
#define __RF24_INCLUDES_H__

  #define RF24_BBB
  #include "BBB/RF24_arch_config.h"
  
#endif